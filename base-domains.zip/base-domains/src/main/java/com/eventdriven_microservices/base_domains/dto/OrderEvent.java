package com.eventdriven_microservices.base_domains.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderEvent {
    //This is the clas we will use to transfer the data
    // between PRODUCER and CONSUMER using KAFKA

    private String message;
    private String status;
    private Order order;
}
