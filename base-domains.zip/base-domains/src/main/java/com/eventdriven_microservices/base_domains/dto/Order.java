package com.eventdriven_microservices.base_domains.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Order {

    private String orderId;
    private String orderName;
    private int qty;
    private double price;
}
